#include <stdio.h>
int main()
{
 /*this is my comment, I'm Jibram*/
 /* 
    d is for integer
    s is for strings
    f is for float
 */
 printf("Welcome to CSE 31!\n");
 return 0;
}
